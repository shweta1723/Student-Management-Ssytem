﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentManagement_day19
{
    public partial class Show_details : Form
    {
        public Show_details()
        {
            InitializeComponent();
        }

        private void Show_details_Load(object sender, EventArgs e)
        {
            //MessageBox.Show(Form1.stulist.Count.ToString());
            foreach(var ob in Form1.stulist)
            {
                listStudent.Items.Add(ob.Data_string());
            }           

        }
    }
}
