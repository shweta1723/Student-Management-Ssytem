﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentManagement_day19
{
    public partial class Form1 : Form
    {
        public static List<Student> stulist = new List<Student>();
        public Form1()
        {
            InitializeComponent();
            
        }
        public Form1(Student ob)
        {
            InitializeComponent();
            stulist.Add(ob);
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btninsert_Click(object sender, EventArgs e)
        {
            InsertRecords ob = new InsertRecords();
            ob.Show();
            this.Hide();
        }

        private void btnshow_Click(object sender, EventArgs e)
        {
            //MessageBox.Show(Form1.stulist.Count.ToString());

            Show_details ob = new Show_details();
            ob.Show();
            this.Hide();
        }
    }
}
