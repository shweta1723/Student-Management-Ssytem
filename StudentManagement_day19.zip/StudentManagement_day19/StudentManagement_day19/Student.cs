﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentManagement_day19
{
    public class Student
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Course { get; set; }
        public string Email { get; set; }
        public float Fees { get; set; }
        public int[] marks{ get; set; }
        public Student()
        {
            marks = new int[3];
        }
        public string Data_string()
        {
            string mydata = "";
            mydata =    "Id       =" + Id;
            mydata += " | Name    = " + Name;
            mydata += " | Course  = " + Course;
            mydata += " | Email   = " + Email;
            mydata += " | Fees    = " + Fees.ToString();
            mydata += " | M1      = " + marks[0].ToString();
            mydata += " | M2      = " + marks[1].ToString();
            mydata += " | M3      = " + marks[2].ToString();

            return mydata;
        }
    }
    

}
