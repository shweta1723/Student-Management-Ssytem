﻿using System;
using System.Windows.Forms;

namespace StudentManagement_day19
{
    public partial class InsertRecords : Form
    {
        public Student stu;
        public InsertRecords()
        {
            InitializeComponent();
            stu = new Student();
        }   

        private void btnsubmit_Click(object sender, EventArgs e)
        {
            stu.Id = int.Parse(txtId.Value.ToString());
            stu.Name = txtName.Text;
            stu.Email = txtEmail.Text;
            stu.Course = txtCourse.Text;
            stu.Fees = float.Parse(txtfees.Value.ToString());
            stu.marks[0] = int.Parse(txtm1.Value.ToString());
            stu.marks[1] = int.Parse(txtm2.Value.ToString());
            stu.marks[2] = int.Parse(txtm3.Value.ToString());
            
            Form1 ob = new Form1(stu);
            ob.Show();
            this.Hide();
        }
    }
}
